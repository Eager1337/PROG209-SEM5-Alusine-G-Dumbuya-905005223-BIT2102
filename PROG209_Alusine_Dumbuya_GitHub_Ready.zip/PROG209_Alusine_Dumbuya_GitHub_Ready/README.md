# PROG209 Event Driven Programming — Assignment 1

## Basic Interactive GUI

**Student:** Alusine G Dumbuya  
**Student ID:** 905005223  
**Programme:** BIT2101  
**Semester:** 4

### About the project

This is a Java Swing application for the PROG209 Event Driven Programming assignment.

The program demonstrates:

- `JFrame`
- `JPanel`
- `JLabel`
- `ImageIcon`
- inheritance
- constructors
- event handling
- changing the welcome text
- changing the panel background
- resetting the interface

The application window is titled **Java Swing Assignment** and is set to **800 × 800** pixels.

### Run the program

You need JDK 17 or newer.

From the project folder:

```text
javac -d out src/SwingAssignment.java
java -cp out SwingAssignment
```

You can also open the project in VS Code or IntelliJ IDEA and run `SwingAssignment.java`.

### Project folders

- `src/` — Java source code
- `assets/` — application icon
- `documentation/` — running application screenshot
- `wireframes/` — GUI wireframe
- `docs/` — assignment documentation
- `out/` — compiled class files if generated locally

### Submission

The documentation includes the wireframe and a screenshot of the running application.

If the lecturer requires GitHub, create a repository, upload the contents of this folder, and add the lecturer as a collaborator using GitHub's repository settings.
